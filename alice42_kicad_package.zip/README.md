# Alice42 wireless Alice keyboard starter package

This package is a KiCad-friendly starter, not a fully wired production schematic.

## Assumptions
- 42 keys total
- Matrix: 4 rows x 12 columns
- Wireless controller: nice!nano (Pro Micro footprint)
- Firmware target: ZMK / ZMK Studio
- Keycaps: Cherry-profile compatible; switch footprint choice must match your real switch hardware

## Included files
- `alice42_starter.kicad_sch`: opens in KiCad as a starter note sheet
- `alice42_simple.kicad_sym`: very small custom symbol library for manual schematic capture
- `alice42_matrix.csv`: switch-to-matrix assignment
- `nice_nano_pin_plan.csv`: proposed GPIO assignment

## Matrix view
- ROW0: C0:SW1 | C1:SW4(Q) | C2:SW8(W) | C3:SW11(E) | C4:SW15(R) | C5:SW18(T) | C6:SW22(Y) | C7:SW26(U) | C8:SW29(I) | C9:SW33(O) | C10:SW36(P) | C11:SW40(-)
- ROW1: C0:SW2 | C1:SW5(A) | C2:SW9(S) | C3:SW12(D) | C4:SW16(F) | C5:SW19(G) | C6:SW23(H) | C7:SW27(J) | C8:SW30(K) | C9:SW34(L) | C10:SW37(;) | C11:SW41(Enter)
- ROW2: C0:SW3 | C1:SW6(Z) | C2:SW10(X) | C3:SW13(C) | C4:SW17(V) | C5:SW20(B) | C6:SW24(N) | C7:SW28(M) | C8:SW31(<) | C9:SW35(>) | C10:SW38(?) | C11:SW42(/)
- ROW3: C1:SW7 | C3:SW14 | C4:SW21(Space) | C6:SW25(Space) | C7:SW32(Ctrl) | C10:SW39

## Notes
- For ZMK Studio, the PCB itself does not need a special circuit beyond a sane matrix + nice!nano + power/reset.
- Validate the proposed GPIOs against your exact nice!nano pinout and any future peripherals.
- If you are truly using MX/Cherry-style switches, 17 mm pitch is generally not recommended because caps can interfere. Cherry profile keycaps alone do not determine the switch footprint.
- If you want, the next step is for me to generate a more opinionated package: either a full KiCad schematic draft with 42 switch/diode instances, or a KiCad PCB starter with switch coordinates.